window.onload = function (){
	var userNameId = document.getElementById("userNameId");
	var passName = document.getElementById("userName");
	//通行证 
		//获取焦点与失去焦点事件
	passName.onfocus = function(){
		userNameId.innerHTML = "";
		userNameId.style.border = "none";
		errorWorn(userNameId,"1、由字母、数字、下划线、点、减号组成 \n2、只能以数字、字母开头或结尾，且长度为4-18");
//		console.log("true");
	}
	passName.onblur = function (){
		var reg = /^[0-9A-Za-z]\w{2,16}[0-9A-Za-z]$/gi;
		if(judge(passName.value,reg)==0){
			userNameId.innerHTML = "";
			userNameId.style.border = "none";
			errorWorn(userNameId,"通行证用户名不能为空，请输入")
		}else if(judge(passName.value,reg)== 1){
			userNameId.innerHTML = "";
			userNameId.style.border = "none";
			trueImg(userNameId);
		}	
	}
	
	//创建一个函数 用于添加 输入正确时 的 img
	function trueImg(parent){
		var img = document.createElement("img");
		img.style.src = "images/li_ok.gif";
		parent.appendChild(img);
	}
	//创建一个函数 用于判断输入是否 复合要求 0为空，1为输入合法，-1为不合法；
	function judge(content,regular){
		if(content==""){
			return 0;
		}else{
			return regular.test(content)? 1 :-1;
		}
	}
	
	//创建一个函数 用于 的提示
	function errorWorn(parent,text){
		var image = document.createElement("img");
		var txt = document.createTextNode(text);
		image.style.src = "images/li_err.gif";
		parent.appendChild(image);
		parent.appendChild(txt);
		parent.style.border = "1px solid red";
		parent.style.backgroundColor = "pink";
		parent.style.position = "absolute";
		parent.style.left = 320+"px"
	}
	
	
	
	
	
	
	
	
	
	
}